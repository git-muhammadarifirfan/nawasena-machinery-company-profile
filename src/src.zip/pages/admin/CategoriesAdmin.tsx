import React, { useEffect, useState } from "react";
import type { Category } from "../../lib/types";
import { adminCreateCategory, adminDeleteCategory, adminUpdateCategory, listCategories } from "../../lib/db";
import { Card, CardBody } from "../../ui/Card";
import { Button } from "../../ui/Button";
import { Input } from "../../ui/Input";
import { useToast } from "../../ui/Toast";

export default function CategoriesAdmin() {
  const toast = useToast();
  const [items, setItems] = useState<Category[]>([]);
  const [name, setName] = useState("");
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    try {
      setItems(await listCategories());
    } catch (err: any) {
      toast.push({ kind: "err", title: "Gagal memuat", desc: err?.message });
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  async function add() {
    if (!name.trim()) return;
    try {
      await adminCreateCategory(name.trim());
      toast.push({ kind: "ok", title: "Kategori dibuat" });
      setName("");
      await load();
    } catch (err: any) {
      toast.push({ kind: "err", title: "Gagal simpan", desc: err?.message });
    }
  }

  async function rename(id: string, old: string) {
    const next = prompt("Ubah nama kategori:", old);
    if (!next || !next.trim()) return;
    try {
      await adminUpdateCategory(id, next.trim());
      toast.push({ kind: "ok", title: "Kategori diupdate" });
      await load();
    } catch (err: any) {
      toast.push({ kind: "err", title: "Gagal update", desc: err?.message });
    }
  }

  async function del(id: string) {
    if (!confirm("Hapus kategori ini?")) return;
    try {
      await adminDeleteCategory(id);
      toast.push({ kind: "ok", title: "Kategori dihapus" });
      await load();
    } catch (err: any) {
      toast.push({ kind: "err", title: "Gagal hapus", desc: err?.message });
    }
  }

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card>
        <CardBody>
          <div className="text-sm font-semibold">Tambah Kategori</div>
          <div className="mt-3 flex gap-2">
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Contoh: Mesin Kemasan" />
            <Button className="h-10" onClick={add}>Tambah</Button>
          </div>
          <div className="mt-2 text-[11px] text-white/50">Kategori dipakai untuk filter di halaman Katalog.</div>
        </CardBody>
      </Card>

      <Card>
        <CardBody>
          <div className="flex items-center justify-between">
            <div className="text-sm font-semibold">Daftar Kategori</div>
            <Button variant="ghost" className="h-9" onClick={load}>Refresh</Button>
          </div>

          {loading ? (
            <div className="mt-4 text-white/60">Memuat…</div>
          ) : items.length === 0 ? (
            <div className="mt-4 text-white/60">Belum ada kategori.</div>
          ) : (
            <div className="mt-4 space-y-2">
              {items.map((c) => (
                <div key={c.id} className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/5 px-4 py-3">
                  <div className="text-sm">{c.name}</div>
                  <div className="flex gap-2">
                    <Button className="h-9" onClick={() => rename(c.id, c.name)}>Edit</Button>
                    <Button variant="danger" className="h-9" onClick={() => del(c.id)}>Hapus</Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardBody>
      </Card>
    </div>
  );
}
