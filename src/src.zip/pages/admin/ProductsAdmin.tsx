import React, { useEffect, useMemo, useState } from "react";
import type { Category, Product } from "../../lib/types";
import { listCategories, listProducts, adminCreateProduct, adminDeleteProduct, adminUpdateProduct } from "../../lib/db";
import { Card, CardBody, Badge } from "../../ui/Card";
import { Button } from "../../ui/Button";
import { Input, Textarea } from "../../ui/Input";
import { rupiah } from "../../ui/format";
import { useToast } from "../../ui/Toast";
import { uploadProductImage } from "../../lib/storage";

const empty: Partial<Product> = {
  title: "",
  description: "",
  price: 0,
  category_id: null,
  image_url: null,
  is_recommended: false,
  features: []
};

export default function ProductsAdmin() {
  const toast = useToast();
  const [cats, setCats] = useState<Category[]>([]);
  const [items, setItems] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  const [mode, setMode] = useState<"create" | "edit">("create");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<Partial<Product>>(empty);

  const [imageFile, setImageFile] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);

  const [featureInput, setFeatureInput] = useState("");
  const [features, setFeatures] = useState<string[]>([]);

  async function load() {
    setLoading(true);
    try {
      const [c, p] = await Promise.all([listCategories(), listProducts()]);
      setCats(c);
      setItems(p);
    } catch (err: any) {
      toast.push({ kind: "err", title: "Gagal memuat", desc: err?.message });
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  function reset() {
    setMode("create");
    setEditingId(null);
    setForm(empty);
    setImageFile(null);
    setFeatures([]);
    setFeatureInput("");
  }

  const canSave = useMemo(() => {
    return !!form.title?.trim() && !!form.description?.trim() && Number(form.price || 0) >= 0;
  }, [form]);

  async function save() {
    if (!canSave) return;
    setSaving(true);

    try {
      let imageUrl = form.image_url ?? null;
      if (imageFile) {
        const up = await uploadProductImage(imageFile);
        imageUrl = up.publicUrl;
      }

      const payload: Partial<Product> = {
        title: String(form.title).trim(),
        description: String(form.description).trim(),
        price: Number(form.price || 0),
        category_id: form.category_id || null,
        image_url: imageUrl,
        is_recommended: !!form.is_recommended,
        features: (features || []).map((x) => x.trim()).filter(Boolean)
      };

      if (mode === "create") {
        await adminCreateProduct(payload);
        toast.push({ kind: "ok", title: "Produk dibuat" });
      } else if (editingId) {
        await adminUpdateProduct(editingId, payload);
        toast.push({ kind: "ok", title: "Produk diupdate" });
      }

      reset();
      await load();
    } catch (err: any) {
      toast.push({ kind: "err", title: "Gagal simpan", desc: err?.message });
    } finally {
      setSaving(false);
    }
  }

  async function del(id: string) {
    if (!confirm("Hapus produk ini?")) return;
    try {
      await adminDeleteProduct(id);
      toast.push({ kind: "ok", title: "Produk dihapus" });
      await load();
    } catch (err: any) {
      toast.push({ kind: "err", title: "Gagal hapus", desc: err?.message });
    }
  }

  return (
    <div className="grid gap-4 lg:grid-cols-5">
      <Card className="lg:col-span-2">
        <CardBody>
          <div className="flex items-center justify-between">
            <div className="text-sm font-semibold">{mode === "create" ? "Tambah Produk" : "Edit Produk"}</div>
            {mode === "edit" ? (
              <Button variant="ghost" className="h-9" onClick={reset}>
                Batal
              </Button>
            ) : null}
          </div>

          <div className="mt-4 space-y-3">
            <div>
              <div className="mb-1 text-xs text-white/70">Judul *</div>
              <Input value={form.title ?? ""} onChange={(e) => setForm((p) => ({ ...p, title: e.target.value }))} />
            </div>

            <div>
              <div className="mb-1 text-xs text-white/70">Deskripsi *</div>
              <Textarea
                value={form.description ?? ""}
                onChange={(e) => setForm((p) => ({ ...p, description: e.target.value }))}
                placeholder="Deskripsi umum produk..."
              />
            </div>

            <div>
              <div className="mb-1 text-xs text-white/70">Detail Poin (Specs)</div>
              <div className="flex gap-2">
                <Input
                  value={featureInput}
                  onChange={(e) => setFeatureInput(e.target.value)}
                  placeholder="Contoh: Kapasitas 5kg/batch"
                />
                <Button
                  className="h-10"
                  type="button"
                  onClick={() => {
                    const v = featureInput.trim();
                    if (!v) return;
                    setFeatures((prev) => [...prev, v]);
                    setFeatureInput("");
                  }}
                >
                  + Tambah
                </Button>
              </div>

              {features.length > 0 ? (
                <div className="mt-3 space-y-2">
                  {features.map((f, idx) => (
                    <div
                      key={`${f}-${idx}`}
                      className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/5 px-4 py-3"
                    >
                      <div className="text-sm text-white/80">{f}</div>
                      <div className="flex gap-2">
                        <Button
                          variant="ghost"
                          className="h-9"
                          type="button"
                          onClick={() => {
                            if (idx === 0) return;
                            setFeatures((prev) => {
                              const next = [...prev];
                              [next[idx - 1], next[idx]] = [next[idx], next[idx - 1]];
                              return next;
                            });
                          }}
                        >
                          ↑
                        </Button>
                        <Button
                          variant="ghost"
                          className="h-9"
                          type="button"
                          onClick={() => {
                            if (idx === features.length - 1) return;
                            setFeatures((prev) => {
                              const next = [...prev];
                              [next[idx + 1], next[idx]] = [next[idx], next[idx + 1]];
                              return next;
                            });
                          }}
                        >
                          ↓
                        </Button>
                        <Button
                          variant="danger"
                          className="h-9"
                          type="button"
                          onClick={() => setFeatures((prev) => prev.filter((_, i) => i !== idx))}
                        >
                          Hapus
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="mt-2 text-[11px] text-white/50">
                  Tambahkan poin detail seperti kapasitas, material, daya, dll.
                </div>
              )}
            </div>

            <div className="grid gap-3 md:grid-cols-2">
              <div>
                <div className="mb-1 text-xs text-white/70">Harga</div>
                <Input
                  value={String(form.price ?? 0)}
                  onChange={(e) => setForm((p) => ({ ...p, price: Number(e.target.value || 0) }))}
                  inputMode="numeric"
                />
              </div>

              <div>
                <div className="mb-1 text-xs text-white/70">Kategori</div>
                <select
                  value={form.category_id ?? ""}
                  onChange={(e) => setForm((p) => ({ ...p, category_id: e.target.value || null }))}
                  className="h-10 w-full rounded-2xl border border-white/10 bg-white/5 px-3 text-sm outline-none"
                >
                  <option value="">-</option>
                  {cats.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <div className="mb-1 text-xs text-white/70">Gambar Produk (Upload PNG/JPG/JPEG/WEBP)</div>
              <input
                type="file"
                accept="image/png,image/jpeg,image/jpg,image/webp"
                className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-2 text-sm file:mr-3 file:rounded-xl file:border file:border-white/10 file:bg-white/10 file:px-3 file:py-1 file:text-xs file:text-white/90 hover:bg-white/7"
                onChange={(e) => setImageFile(e.target.files?.[0] ?? null)}
              />

              {(form.image_url || imageFile) ? (
                <div className="mt-3 overflow-hidden rounded-2xl border border-white/10 bg-black/30">
                  <img
                    src={imageFile ? URL.createObjectURL(imageFile) : (form.image_url as string)}
                    alt="preview"
                    className="h-40 w-full object-cover"
                  />
                </div>
              ) : null}

              <div className="mt-2 text-[11px] text-white/50">
                {mode === "edit" ? "Kosongkan jika tidak ingin mengganti gambar." : "Pilih gambar untuk tampil di katalog."}
              </div>
            </div>

            <label className="flex items-center gap-2 text-sm text-white/70">
              <input
                type="checkbox"
                checked={!!form.is_recommended}
                onChange={(e) => setForm((p) => ({ ...p, is_recommended: e.target.checked }))}
              />
              Jadikan Rekomendasi
            </label>

            <Button className="h-11 w-full" onClick={save} disabled={!canSave || saving}>
              {saving ? "Menyimpan..." : mode === "create" ? "Simpan Produk" : "Update Produk"}
            </Button>
          </div>
        </CardBody>
      </Card>

      <Card className="lg:col-span-3">
        <CardBody>
          <div className="flex items-center justify-between">
            <div className="text-sm font-semibold">Daftar Produk</div>
            <Button variant="ghost" className="h-9" onClick={load}>
              Refresh
            </Button>
          </div>

          {loading ? (
            <div className="mt-4 text-white/60">Memuat...</div>
          ) : items.length === 0 ? (
            <div className="mt-4 text-white/60">Belum ada produk.</div>
          ) : (
            <div className="mt-4 grid gap-3">
              {items.map((p) => (
                <div
                  key={p.id}
                  className="flex flex-col gap-3 rounded-2xl border border-white/10 bg-white/5 p-4 md:flex-row md:items-center md:justify-between"
                >
                  <div className="flex items-center gap-3">
                    <div className="h-12 w-16 overflow-hidden rounded-xl border border-white/10 bg-black/30">
                      {p.image_url ? <img src={p.image_url} className="h-full w-full object-cover" alt={p.title} /> : null}
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <div className="text-sm font-semibold">{p.title}</div>
                        {p.is_recommended ? <Badge>Rekomendasi</Badge> : null}
                      </div>
                      <div className="mt-1 text-xs text-white/60 line-clamp-1">{p.description}</div>
                      <div className="mt-1 text-xs text-white/60">{rupiah(Number(p.price))}</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Button
                      className="h-9"
                      onClick={() => {
                        setMode("edit");
                        setEditingId(p.id);
                        setForm({
                          title: p.title,
                          description: p.description,
                          price: Number(p.price),
                          category_id: p.category_id,
                          image_url: p.image_url ?? null,
                          is_recommended: p.is_recommended,
                          features: p.features ?? []
                        });
                        setFeatures(p.features ?? []);
                        setFeatureInput("");
                        setImageFile(null);
                      }}
                    >
                      Edit
                    </Button>

                    <Button variant="danger" className="h-9" onClick={() => del(p.id)}>
                      Hapus
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardBody>
      </Card>
    </div>
  );
}
