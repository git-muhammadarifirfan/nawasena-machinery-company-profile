import React, { useEffect, useState } from "react";
import { Card, CardBody } from "../../ui/Card";
import { Button } from "../../ui/Button";
import { Input } from "../../ui/Input";
import { adminListAdmins } from "../../lib/db";
import { supabase } from "../../lib/supabase";
import { useToast } from "../../ui/Toast";

const ENABLE_INVITE = String(import.meta.env.VITE_ENABLE_INVITE_FUNCTION || "0") === "1";

export default function UsersAdmin() {
  const toast = useToast();
  const [admins, setAdmins] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  async function load() {
    setLoading(true);
    try {
      setAdmins(await adminListAdmins());
    } catch (err: any) {
      toast.push({ kind: "err", title: "Gagal memuat", desc: err?.message });
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  async function addAdmin() {
    if (!ENABLE_INVITE) {
      toast.push({ kind: "err", title: "Edge Function belum aktif", desc: "Set VITE_ENABLE_INVITE_FUNCTION=1 setelah deploy fungsi invite-admin." });
      return;
    }
    if (!email.trim() || !password.trim()) {
      toast.push({ kind: "err", title: "Lengkapi form", desc: "Email & password wajib." });
      return;
    }
    try {
      const { data: session } = await supabase.auth.getSession();
      const token = session.session?.access_token;
      if (!token) throw new Error("Session tidak ditemukan.");

      const res = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/invite-admin`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ email: email.trim(), password: password.trim() })
      });

      if (!res.ok) {
        const t = await res.text();
        throw new Error(t || "Request failed");
      }

      toast.push({ kind: "ok", title: "Admin dibuat", desc: "Admin baru bisa login pakai email & password ini." });
      setEmail("");
      setPassword("");
      await load();
    } catch (err: any) {
      toast.push({ kind: "err", title: "Gagal tambah admin", desc: err?.message });
    }
  }

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card>
        <CardBody>
          <div className="text-sm font-semibold">Tambah Admin Baru</div>
          <div className="mt-2 text-xs text-white/60">
            Aman karena dibuat via <b>Supabase Edge Function</b> (server-side). Jika belum deploy, buat admin manual di Supabase.
          </div>

          <div className="mt-4 space-y-3">
            <div>
              <div className="mb-1 text-xs text-white/70">Email</div>
              <Input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="admin2@nawasena.id" type="email" />
            </div>
            <div>
              <div className="mb-1 text-xs text-white/70">Password</div>
              <Input value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" type="password" />
            </div>
            <Button className="h-11 w-full" onClick={addAdmin}>Buat Admin</Button>

            {!ENABLE_INVITE ? (
              <div className="rounded-2xl border border-amber-500/20 bg-amber-500/10 p-3 text-[11px] text-amber-100/90">
                Invite function belum aktif. Deploy `supabase/functions/invite-admin` lalu set <b>VITE_ENABLE_INVITE_FUNCTION=1</b>.
              </div>
            ) : null}
          </div>
        </CardBody>
      </Card>

      <Card>
        <CardBody>
          <div className="flex items-center justify-between">
            <div className="text-sm font-semibold">Daftar Admin</div>
            <Button variant="ghost" className="h-9" onClick={load}>Refresh</Button>
          </div>
          {loading ? (
            <div className="mt-4 text-white/60">Memuat…</div>
          ) : admins.length === 0 ? (
            <div className="mt-4 text-white/60">Belum ada admin.</div>
          ) : (
            <div className="mt-4 space-y-2">
              {admins.map((a) => (
                <div key={a.user_id} className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm">
                  <div className="text-white/80">User ID:</div>
                  <div className="mt-1 font-mono text-xs text-white/60 break-all">{a.user_id}</div>
                  <div className="mt-1 text-[11px] text-white/45">
                    Added: {a.created_at ? new Date(a.created_at).toLocaleString("id-ID") : "-"}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardBody>
      </Card>
    </div>
  );
}
