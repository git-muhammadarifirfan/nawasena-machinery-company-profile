import React, { useEffect, useState } from "react";
import { Card, CardBody } from "../../ui/Card";
import { Button } from "../../ui/Button";
import { Input, Textarea } from "../../ui/Input";
import { useToast } from "../../ui/Toast";
import { adminUpsertSetting, getSettingsMap } from "../../lib/db";
import { uploadSiteLogo } from "../../lib/storage";
import { useSiteSettings } from "../../state/siteSettings";

const KEYS = [
  "admin_whatsapp",
  "site_name",
  "logo_url",
  "about_title",
  "about_text",
  "footer_address",
  "footer_phone",
  "footer_email",
  "instagram_url",
  "facebook_url"
] as const;

type Key = (typeof KEYS)[number];

export default function SettingsAdmin() {
  const toast = useToast();
  const { refresh } = useSiteSettings();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [form, setForm] = useState<Record<Key, string>>({
    admin_whatsapp: "6281234567890",
    site_name: "Nawasena Machinery",
    logo_url: "",
    about_title: "Tentang Kami",
    about_text: "",
    footer_address: "",
    footer_phone: "",
    footer_email: "",
    instagram_url: "",
    facebook_url: ""
  });

  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        const map = await getSettingsMap(KEYS as unknown as string[]);
        setForm((prev) => ({ ...prev, ...(map as any) }));
      } catch (e: any) {
        toast.push({ kind: "err", title: "Gagal memuat settings", desc: e?.message });
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  async function save() {
    setSaving(true);
    try {
      let logoUrl = form.logo_url || "";

      if (logoFile) {
        const up = await uploadSiteLogo(logoFile);
        logoUrl = up.publicUrl;
      }

      const patch: Record<Key, string> = {
        ...form,
        logo_url: logoUrl
      };

      await Promise.all(
        Object.entries(patch).map(([k, v]) => adminUpsertSetting(k, String(v ?? "")))
      );

      toast.push({ kind: "ok", title: "Settings tersimpan" });
      setLogoFile(null);
      await refresh();
    } catch (e: any) {
      toast.push({ kind: "err", title: "Gagal simpan", desc: e?.message });
    } finally {
      setSaving(false);
    }
  }

  if (loading) return <div className="text-white/60">Memuat…</div>;

  return (
    <div className="grid gap-4">
      <Card>
        <CardBody>
          <div className="text-sm font-semibold">Branding</div>

          <div className="mt-4 grid gap-3 md:grid-cols-2">
            <div>
              <div className="mb-1 text-xs text-white/70">Nama Toko</div>
              <Input value={form.site_name} onChange={(e) => setForm((p) => ({ ...p, site_name: e.target.value }))} />
            </div>

            <div>
              <div className="mb-1 text-xs text-white/70">Logo (Upload)</div>
              <input
                type="file"
                accept="image/png,image/jpeg,image/jpg,image/webp"
                className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-2 text-sm file:mr-3 file:rounded-xl file:border file:border-white/10 file:bg-white/10 file:px-3 file:py-1 file:text-xs file:text-white/90 hover:bg-white/7"
                onChange={(e) => setLogoFile(e.target.files?.[0] ?? null)}
              />

              {(form.logo_url || logoFile) ? (
                <div className="mt-3 overflow-hidden rounded-2xl border border-white/10 bg-black/30 p-2">
                  <img
                    src={logoFile ? URL.createObjectURL(logoFile) : form.logo_url}
                    className="h-20 w-20 rounded-xl object-cover"
                    alt="logo"
                  />
                </div>
              ) : (
                <div className="mt-2 text-[11px] text-white/50">Belum ada logo. Default akan tampil NM.</div>
              )}
            </div>
          </div>
        </CardBody>
      </Card>

      <Card>
        <CardBody>
          <div className="text-sm font-semibold">Tentang Kami</div>
          <div className="mt-4 grid gap-3">
            <div>
              <div className="mb-1 text-xs text-white/70">Judul</div>
              <Input value={form.about_title} onChange={(e) => setForm((p) => ({ ...p, about_title: e.target.value }))} />
            </div>
            <div>
              <div className="mb-1 text-xs text-white/70">Isi</div>
              <Textarea
                value={form.about_text}
                onChange={(e) => setForm((p) => ({ ...p, about_text: e.target.value }))}
                placeholder="Tulis profil perusahaan..."
              />
            </div>
          </div>
        </CardBody>
      </Card>

      <Card>
        <CardBody>
          <div className="text-sm font-semibold">Footer & Kontak</div>

          <div className="mt-4 grid gap-3 md:grid-cols-2">
            <div className="md:col-span-2">
              <div className="mb-1 text-xs text-white/70">Alamat</div>
              <Textarea value={form.footer_address} onChange={(e) => setForm((p) => ({ ...p, footer_address: e.target.value }))} />
            </div>

            <div>
              <div className="mb-1 text-xs text-white/70">Telepon</div>
              <Input value={form.footer_phone} onChange={(e) => setForm((p) => ({ ...p, footer_phone: e.target.value }))} />
            </div>

            <div>
              <div className="mb-1 text-xs text-white/70">Email</div>
              <Input value={form.footer_email} onChange={(e) => setForm((p) => ({ ...p, footer_email: e.target.value }))} />
            </div>

            <div>
              <div className="mb-1 text-xs text-white/70">Instagram URL</div>
              <Input value={form.instagram_url} onChange={(e) => setForm((p) => ({ ...p, instagram_url: e.target.value }))} placeholder="https://instagram.com/..." />
            </div>

            <div>
              <div className="mb-1 text-xs text-white/70">Facebook URL</div>
              <Input value={form.facebook_url} onChange={(e) => setForm((p) => ({ ...p, facebook_url: e.target.value }))} placeholder="https://facebook.com/..." />
            </div>
          </div>
        </CardBody>
      </Card>

      <Card>
        <CardBody>
          <div className="text-sm font-semibold">WhatsApp Penerima Checkout</div>
          <div className="mt-4">
            <div className="mb-1 text-xs text-white/70">Nomor WhatsApp (62xxxx)</div>
            <Input
              value={form.admin_whatsapp}
              onChange={(e) => setForm((p) => ({ ...p, admin_whatsapp: e.target.value }))}
              placeholder="6281234567890"
            />
            <div className="mt-2 text-[11px] text-white/50">Format disarankan: 62xxxx (tanpa +).</div>
          </div>

          <div className="mt-5">
            <Button className="h-11" onClick={save} disabled={saving}>
              {saving ? "Menyimpan..." : "Simpan Settings"}
            </Button>
          </div>
        </CardBody>
      </Card>
    </div>
  );
}
